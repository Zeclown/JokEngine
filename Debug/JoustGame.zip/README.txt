This is an exemple game made with JokEngine https://github.com/Zeclown/JokEngine
It is a copy of Joust, the old arcade game.
You will need to install OpenAL for it to work.
The source code is available here: https://github.com/Zeclown/JokEngine/tree/Game_Example_Dev


Controls:
Player 1:WASD to move
Player 2:Enter to join, Arrow Keys to move

Rules:
When two knights collide, the highest knight wins.
Enemies drop eggs when they die and will respawn unless you collect the egg.
Beware the lava.


-Pierre-Olivier Chartrand


